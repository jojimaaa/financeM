import AccountSettingsForm from "../components/AccountSettingsForm.tsx";

export function Conta() {
  return (
    <div className="w-full h-full flex justify-center items-center">
      <AccountSettingsForm />
    </div>
  );
}
